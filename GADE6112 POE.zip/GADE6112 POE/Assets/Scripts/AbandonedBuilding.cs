﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AbandonedBuilding : MonoBehaviour {
    public GameObject[] Abandoned;

    public float waitingForNextSpawn = 10;

    public float Countdown = 10;

    public float xMin;

    public float xMax;

    public float yMin;

    public float yMax;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        Countdown -= Time.deltaTime;
        if(Countdown <= 0)
        {
            SpawnAbandBuild();
            Countdown = waitingForNextSpawn;
        }
    }

    void SpawnAbandBuild()
    {
        Vector2 pos = new Vector2(Random.Range(xMin, xMax), Random.Range(yMin, yMax));

        GameObject AbandBuildPrefab = Abandoned[Random.Range(0, Abandoned.Length)];

        Instantiate (AbandBuildPrefab, pos, transform.rotation);


    }
}
