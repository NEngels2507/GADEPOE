﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResourceBuilding : MonoBehaviour {
    public GameObject[] Resource;

    public float waitingForNextSpawn = 10;

    public float Countdown = 10;
    public float xMin;
    public float xMax;

    public float yMin;
    public float yMax;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        Countdown -= Time.deltaTime;
        if (Countdown <= 0)
        {
            SpawnResource();
            Countdown = waitingForNextSpawn;
        }
    }

    void SpawnResource()
    {
        Vector2 pos = new Vector2(Random.Range(xMin, xMax), Random.Range(yMin, yMax));

        GameObject ResourcePrefab = Resource[Random.Range(0, Resource.Length)];

        Instantiate(ResourcePrefab, pos, transform.rotation);
    }
}

