﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RangedclassEnemy : MovingObject
{
    public GameObject[] RangedEnemy;

    public Transform RangedEnemyPOS;

    public float waitingForNextSpawn = 10;

    public float Countdown = 10;

    public float xMin;

    public float xMax;

    public float yMin;

    public float yMax;

    public float Movement = 10;

    public int AttackDamage;

    private Transform target;
    private object GameManager;



    // Use this for initialization
    protected override void Start()
    {
        target = GameObject.FindGameObjectWithTag("Melee").transform;
        target = GameObject.FindGameObjectWithTag("Sniper").transform;
        target = GameObject.FindGameObjectWithTag("General").transform;
        target = GameObject.FindGameObjectWithTag("SpecialForces").transform;
    }

    protected override void AttemptMove<T>(int xDir, int yDir)
    {

    }

    public void MoveEnemy()
    {
        int xDir = 0;
        int yDir = 0;

        if (Mathf.Abs(target.position.x - transform.position.x) < float.Epsilon)
        {
            yDir = target.position.y > transform.position.y ? 1 : -1;
        }
        else
        {
            xDir = target.position.x > transform.position.x ? 1 : -1;
        }
        AttemptMove<SpecialForces>(xDir, yDir);
    }

    // Update is called once per frame
    void Update()
    {

        Countdown -= Time.deltaTime;
        if (Countdown <= 0)
        {
            SpawnRangedEnemy();
            Countdown = waitingForNextSpawn;
        }

        transform.Translate(Vector3.right * Movement * Time.deltaTime);

    }

    void SpawnRangedEnemy()
    {
        Vector2 pos = new Vector2(Random.Range(xMin, xMax), Random.Range(yMin, yMax));

        GameObject RangedEnemyPrefab = RangedEnemy[Random.Range(0, RangedEnemy.Length)];

        Instantiate(RangedEnemyPrefab, pos, transform.rotation);
    }
}
